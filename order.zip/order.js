console.log("hello");

function renderProductList(data) {
  var productListElement = document.getElementById("cart-list");

  var htmlString = "";

  for (var index in data) {
    htmlString =
      htmlString +
      `
            <tr>
              <td>
                  <img src="${data[index].image}" alt="Giày Nike" class="img-thumbnail me-2" width="50">
                  ${data[index].name}
              </td>
              <td>
                  <input type="number" class="form-control form-control-sm" value="1" min="1" max="10">
              </td>
              <td>${data[index].price}</td>
              <td>${data[index].price}</td>
              <td>
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
              </td>
          </tr>
    `;
  }

  productListElement.innerHTML = htmlString;
}

axios
  .get("https://6044315ca20ace001728eb74.mockapi.io/api/products")
  .then(function (data) {
    var productList = data.data;

    const myCart = JSON.parse(localStorage.getItem("cart")) || [];

    const cartData = [];

    for (var index in myCart) {
      const productId = myCart[index];
      const product = productList.find(function (item) {
        return item.id === productId;
      });

      cartData.push(product);
    }

    console.log(cartData);

    renderProductList(cartData);
  });
